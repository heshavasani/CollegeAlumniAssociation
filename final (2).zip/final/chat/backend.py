from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_cors import CORS
from datetime import datetime
from sqlalchemy import text

# Initialize backend and Extensions ONCE
backend = Flask(__name__)
CORS(backend) # Crucial for "Is backend running" error

backend.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"
backend.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(backend)
bcrypt = Bcrypt(backend)

# --- MODELS ---

class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    department = db.Column(db.String(100))
    batch_year = db.Column(db.Integer)
    linkedin_url = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    events = db.relationship("Event", backref="creator", lazy=True)
    jobs = db.relationship("Job", backref="poster", lazy=True)

class Event(db.Model):
    __tablename__ = "events"
    id = db.Column(db.Integer, primary_key=True)
    created_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    mode = db.Column(db.String(20), nullable=False)
    location = db.Column(db.String(300), nullable=False)
    event_date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Job(db.Model):
    __tablename__ = "jobs"
    id = db.Column(db.Integer, primary_key=True)
    role = db.Column(db.String(150), nullable=False)
    company_name = db.Column(db.String(200), nullable=False)
    location = db.Column(db.String(200), nullable=False)
    paid_status = db.Column(db.String(50), nullable=False)
    duration = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    posted_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

# --- ROUTES ---

@backend.route("/", methods=["GET"])
def home():
    return jsonify({"message": "Server is running"}), 200

@backend.route("/signup", methods=["POST"])
def signup():
    data = request.get_json()
    if not data:
        return jsonify({"message": "No data received"}), 400

    username = data.get("username")
    password = data.get("pass")
    mail = data.get("mail")
    role = data.get("role")
    dept = data.get("dept")
    
    try:
        year = int(data.get("year"))
    except:
        return jsonify({"message": "Invalid year"}), 400

    if User.query.filter_by(email=mail).first():
        return jsonify({"message": "Email already registered"}), 400

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    
    new_user = User(
        username=username,
        email=mail,
        password_hash=hashed_password,
        role=role,
        department=dept,
        batch_year=year
    )

    db.session.add(new_user)
    db.session.commit()
    return jsonify({"message": "Signup Successful"}), 201

@backend.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    user = User.query.filter_by(username=data.get("username")).first()
    if user and bcrypt.check_password_hash(user.password_hash, data.get("password")):
        return jsonify({"message": "Login successful", "user": {"id": user.id, "username": user.username}}), 200
    return jsonify({"message": "Invalid credentials"}), 401

@backend.route("/dashboard-stats", methods=["GET"])
def get_dashboard_stats():
    try:
        # Count total entries in each table
        total_alumni = User.query.filter_by(role='alumni').count()
        total_students = User.query.filter_by(role='student').count()
        
        # This counts every user for the "Connections" stat
        total_connections = User.query.count()
        
        # Count entries in events and jobs tables
        events_count = Event.query.count()
        jobs_count = Job.query.count()

        # You can calculate percentages for your chart here or on the frontend
        total_users = total_connections if total_connections > 0 else 1
        
        return jsonify({
            "total_alumni": total_alumni,
            "total_students": total_students,
            "connections": total_connections,
            "events_count": events_count,
            "jobs_count": jobs_count
        }), 200
    except Exception as e:
        return jsonify({"message": "Error fetching stats", "error": str(e)}), 500
    
@backend.route("/update-profile/<int:user_id>", methods=["PUT"])
def update_profile(user_id):
    data = request.get_json()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({"message": "User not found"}), 404

    try:
        # Update text fields
        user.department = data.get("department", user.department)
        user.batch_year = data.get("batch_year", user.batch_year)
        # Note: We aren't updating username here to keep session stability, 
        # but you could add user.username = data.get("username") if desired.

        db.session.commit()
        return jsonify({"message": "Profile updated in database successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error updating profile", "error": str(e)}), 500
    
if __name__ == "__main__":
    with backend.backend_context():
        db.create_all()
    backend.run(debug=True, port=5000)