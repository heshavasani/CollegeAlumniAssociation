from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)

DB_NAME = "database.db"

def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender TEXT,
            receiver TEXT,
            content TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

init_db()

@app.route("/send", methods=["POST"])
def send_message():
    data = request.json
    conn = get_db()
    conn.execute(
        "INSERT INTO messages (sender, receiver, content) VALUES (?, ?, ?)",
        (data["sender"], data["receiver"], data["content"])
    )
    conn.commit()
    conn.close()
    return jsonify({"ok": True})

@app.route("/messages/<sender>/<receiver>")
def get_messages(sender, receiver):
    conn = get_db()
    rows = conn.execute("""
        SELECT * FROM messages
        WHERE (sender=? AND receiver=?)
           OR (sender=? AND receiver=?)
        ORDER BY timestamp
    """, (sender, receiver, receiver, sender)).fetchall()
    conn.close()

    return jsonify([
        {
            "sender": r["sender"],
            "receiver": r["receiver"],
            "content": r["content"],
            "time": r["timestamp"]
        } for r in rows
    ])

app.run(debug=True)
